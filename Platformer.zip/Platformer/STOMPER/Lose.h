#include "Scene.h"

class Lose : public Scene {
public:
    void Initialize() override;
    void processInput() override;
    void Update(float deltaTime) override;
    void Render(ShaderProgram *program) override;
};

