#include "Level0.h"


#define LEVEL0_WIDTH 14
#define LEVEL0_HEIGHT 8

#define LEVEL0_ENEMY_COUNT 1
bool startGame = false;
unsigned int level0_data[] =
{
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
void Level0::Initialize() {
    state.nextScene = -1;
    GLuint mapTextureID = Util::LoadTexture("tileset.png");
    state.map = new Map(LEVEL0_WIDTH, LEVEL0_HEIGHT, level0_data, mapTextureID, 1.0f, 4, 1);
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(5.25,-6,0);
    state.player->movement = glm::vec3(0);
    state.player->textureID = Util::LoadTexture("timb.png");
    state.player->height = 0.8f;
    state.player->width = 0.8f;
    
    state.enemies = new Entity[1];
}
void Level0::processInput() {
    //SDL_Event event;
    const Uint8 *keys = SDL_GetKeyboardState(NULL);

    if (keys[SDL_SCANCODE_RETURN]) {
        //std::cout << "HERE" << std::endl;
        startGame = true;

    }
}
void Level0::Update(float deltaTime) {
    state.player->Update(deltaTime, state.player, state.enemies, 1, state.map);
    if(startGame){
        state.nextScene = 1;
    }
}
void Level0::Render(ShaderProgram *program){
    state.map->Render(program);
    state.player->Render(program);
}
