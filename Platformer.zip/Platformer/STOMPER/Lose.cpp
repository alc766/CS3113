#include "Lose.h"


#define LOSE_WIDTH 14
#define LOSE_HEIGHT 8



unsigned int lose_data[] =
{
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
void Lose::Initialize() {
    state.nextScene = -1;
    GLuint mapTextureID = Util::LoadTexture("tileset.png");
    state.map = new Map(LOSE_WIDTH, LOSE_HEIGHT, lose_data, mapTextureID, 1.0f, 4, 1);
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(2,-5,0);
    state.player->movement = glm::vec3(0);
    state.player->textureID = Util::LoadTexture("timb.png");
    state.player->height = 0.8f;
    state.player->width = 0.8f;
    
    state.player->isActive = false;
    state.enemies = new Entity[1];
}
void Lose::processInput() {
    
}
void Lose::Update(float deltaTime) {
    state.player->Update(deltaTime, state.player, state.enemies, 1, state.map);
    
}
void Lose::Render(ShaderProgram *program){
    state.map->Render(program);
    state.player->Render(program);
}

