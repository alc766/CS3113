#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <vector>
#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include <SDL_mixer.h>


#include "Util.h"

#include "Entity.h"
#include "Map.h"

#include "Scene.h"
#include "Level0.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "Lose.h"


//music
//Werq by Kevin MacLeod
//Link: https://incompetech.filmmusic.io/song/4616-werq
//License: http://creativecommons.org/licenses/by/4.0/

SDL_Window* displayWindow;
bool gameIsRunning = true;

Scene *currentScene;
Scene *sceneList[5];
void SwitchToScene(Scene *scene) {
    currentScene = scene;
    currentScene->Initialize();
}


int collisionArrayLevel1[1];
int collisionArrayLevel2[1];
int collisionArrayLevel3[1];
bool win = false;
bool fail = false;
int lives = 3;


ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

Mix_Music *music;
Mix_Chunk *crunchCan;
Mix_Chunk *damageTaken;




void Initialize() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    displayWindow = SDL_CreateWindow("STOMPER", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
    
#ifdef _WINDOWS
    glewInit();
#endif
    
    glViewport(0, 0, 640, 480);
    
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    
     Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    music = Mix_LoadMUS("werq.mp3");
    Mix_PlayMusic(music, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 3);
    
    crunchCan = Mix_LoadWAV("slap.wav");
    damageTaken = Mix_LoadWAV("punch.wav");;
    viewMatrix = glm::mat4(1.0f);
    modelMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);
    
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    
    glUseProgram(program.programID);
    
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    glEnable(GL_BLEND);

    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
  sceneList[0] = new Level0();
  sceneList[1] = new Level1();
  sceneList[2] = new Level2();
  sceneList[3] = new Level3();
    sceneList[4] = new Lose();
  SwitchToScene(sceneList[0]);
    // Initialize Game Objects
    
   
   
}

void ProcessInput() {
    
    currentScene->state.player->movement = glm::vec3(0);
    
    if(currentScene == sceneList[0]){
        currentScene->processInput();
    }
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
            case SDL_WINDOWEVENT_CLOSE:
                gameIsRunning = false;
                break;
                
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_LEFT:
                        // Move the player left
                        break;
                        
                    case SDLK_RIGHT:
                        // Move the player right
                        break;
                        
                    case SDLK_SPACE:
                        if(currentScene->state.player->collidedBottom){
                             currentScene->state.player->jump = true;
                        }
                       
                        //state.player->velocity.y = state.player->jumpPower;
                        
                        break;
                }
                break; // SDL_KEYDOWN
        }
    }
    
    const Uint8 *keys = SDL_GetKeyboardState(NULL);
    
    if (keys[SDL_SCANCODE_LEFT]) {
       currentScene->state.player->movement.x = -1.0f;
        
    }
    
    else if (keys[SDL_SCANCODE_RIGHT]) {
       currentScene->state.player->movement.x = 1.0f;
    }
    



}

 #define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;


void Update() {
    
    
    
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP) {
            accumulator = deltaTime;
        return;
        
    }
   
    while (deltaTime >= FIXED_TIMESTEP) {
        //lifeLostFlag = false;
//       Update(float deltaTime, Entity* player, Entity *objects,int objectCount, Map *map)
        currentScene->Update(FIXED_TIMESTEP);
        
       

        if(currentScene->state.player->collidedEnemyBottom == true && currentScene->state.player->collidedEnemyLeft == false && currentScene->state.player->collidedEnemyRight == false &&
           currentScene->state.player->collidedEnemyTop == false){
             if(currentScene == sceneList[1]){
                 if(collisionArrayLevel1[currentScene->state.player->indexOfEnemy] == false){
                     Mix_PlayChannel(-1, crunchCan, 0);
                     Mix_VolumeChunk(crunchCan, MIX_MAX_VOLUME/2);
                 }
                 collisionArrayLevel1[currentScene->state.player->indexOfEnemy] = true;
                 currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
             }
             if(currentScene == sceneList[2]){
                 
                 if(collisionArrayLevel2[currentScene->state.player->indexOfEnemy] == false){
                     Mix_PlayChannel(-1, crunchCan, 0);
                    Mix_VolumeChunk(crunchCan, MIX_MAX_VOLUME/2);
                 }
                 collisionArrayLevel2[currentScene->state.player->indexOfEnemy] = true;
                 currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
             }
             if(currentScene == sceneList[3]){
                 if(collisionArrayLevel3[currentScene->state.player->indexOfEnemy] == false){
                     Mix_PlayChannel(-1, crunchCan, 0);
                    Mix_VolumeChunk(crunchCan, MIX_MAX_VOLUME/2);
                 }
                 collisionArrayLevel3[currentScene->state.player->indexOfEnemy] = true;
                 currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
             }
            
              
             

          }
        if(currentScene->state.player->collidedEnemyLeft == true &&
           currentScene->state.player->collidedEnemyRight == false &&
           currentScene->state.player->collidedEnemyTop == false){
            if(currentScene == sceneList[1]){
                if(collisionArrayLevel1[currentScene->state.player->indexOfEnemy] == false){
                    Mix_PlayChannel(-1, damageTaken, 0);
                    Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                    lives -= 1;
                }
                collisionArrayLevel1[currentScene->state.player->indexOfEnemy] = true;
                currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
            }
           if(currentScene == sceneList[2] && collisionArrayLevel2[currentScene->state.player->indexOfEnemy] == false){
                         Mix_PlayChannel(-1, damageTaken, 0);
                         Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                         lives -= 1;
                         collisionArrayLevel2[currentScene->state.player->indexOfEnemy] = true;
                         currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
                     }
            if(currentScene == sceneList[3]){
                if(collisionArrayLevel3[currentScene->state.player->indexOfEnemy] == false){
                    Mix_PlayChannel(-1, damageTaken, 0);
                    Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                    lives -= 1;
                }
                collisionArrayLevel3[currentScene->state.player->indexOfEnemy] = true;
                currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
            }
        }
        if(currentScene->state.player->collidedEnemyRight == true && currentScene->state.player->collidedEnemyLeft == false &&
           currentScene->state.player->collidedEnemyTop == false){
          
           if(currentScene == sceneList[1]){
               if(collisionArrayLevel1[currentScene->state.player->indexOfEnemy] == false){
                   Mix_PlayChannel(-1, damageTaken, 0);
                   Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                   lives -= 1;
               }
               collisionArrayLevel1[currentScene->state.player->indexOfEnemy] = true;
               currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
           }
           
            if(currentScene == sceneList[2] && collisionArrayLevel2[currentScene->state.player->indexOfEnemy] == false){
               Mix_PlayChannel(-1, damageTaken, 0);
               Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
               lives -= 1;
               collisionArrayLevel2[currentScene->state.player->indexOfEnemy] = true;
               currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
           }
               
           
            if(currentScene == sceneList[3]){
                if(collisionArrayLevel3[currentScene->state.player->indexOfEnemy] == false){
                    Mix_PlayChannel(-1, damageTaken, 0);
                    Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                    lives -= 1;
                }
                collisionArrayLevel3[currentScene->state.player->indexOfEnemy] = true;
                currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
            }
                  
               }
        if(currentScene->state.player->collidedEnemyTop == true &&
           currentScene->state.player->collidedEnemyRight == false && currentScene->state.player->collidedEnemyLeft == false){
          if(currentScene == sceneList[1]){
              if(collisionArrayLevel1[currentScene->state.player->indexOfEnemy] == false){
                  Mix_PlayChannel(-1, damageTaken, 0);
                  Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                  lives -= 1;
              }
              collisionArrayLevel1[currentScene->state.player->indexOfEnemy] = true;
              currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
          }
          if(currentScene == sceneList[2] && collisionArrayLevel2[currentScene->state.player->indexOfEnemy] == false){
                    Mix_PlayChannel(-1, damageTaken, 0);
                    Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                    lives -= 1;
                    collisionArrayLevel2[currentScene->state.player->indexOfEnemy] = true;
                    currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
                    }
            if(currentScene == sceneList[3]){
                if(collisionArrayLevel3[currentScene->state.player->indexOfEnemy] == false){
                    Mix_PlayChannel(-1, damageTaken, 0);
                    Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
                    lives -= 1;
                }
                collisionArrayLevel3[currentScene->state.player->indexOfEnemy] = true;
                currentScene->state.enemies[currentScene->state.player->indexOfEnemy].isActive = false;
            }
                  
               }
        if(currentScene == sceneList[3]){
            
            if(currentScene->state.player->position.x >= 12){
                win = true;
                currentScene->state.player->movement = glm::vec3(0);
                currentScene->state.player->acceleration = glm::vec3(0);
                currentScene->state.player->isActive = false;
            }
        }
        if( currentScene->state.player-> position.y <= -8 && lives > 0){
            currentScene->state.player-> position.x = 1;
            currentScene->state.player-> position.y = -5;
            Mix_PlayChannel(-1, damageTaken, 0);
            Mix_VolumeChunk(damageTaken, MIX_MAX_VOLUME);
            lives -= 1;
        }
        if(lives == 0){
            currentScene->state.player->velocity.x = 0;
            currentScene->state.player->velocity.y = 0;
            currentScene->state.player->acceleration.y = 0;
            currentScene->state.player->isActive = false;
            fail = true;
            SwitchToScene(sceneList[4]);
        }

       
        deltaTime -= FIXED_TIMESTEP;
    
    }
    accumulator = deltaTime;
    
    //std::cout << lives << std::endl;
    if(currentScene->state.player->isActive == true && fail == false){
        viewMatrix = glm::mat4(1.0f);
        if (currentScene->state.player->position.x > 5) {
            viewMatrix = glm::translate(viewMatrix, glm::vec3(-currentScene->state.player->position.x, 3.75, 0));
        }
        
       
        else{
            viewMatrix = glm::translate(viewMatrix, glm::vec3(-5, 3.75, 0));
        }
    }
}

void Render() {
    GLuint fontTextureID = Util::LoadTexture("font1.png");
    program.SetViewMatrix(viewMatrix);
    glClear(GL_COLOR_BUFFER_BIT);

    currentScene->Render(&program);
    
    if(currentScene == sceneList[0]){
        Util::DrawText(&program, fontTextureID, "STOMPER" , 0.75f, -0.25f, glm::vec3(3.5, -3, 0));
        Util::DrawText(&program, fontTextureID, "Press Enter to Start" , 0.6f, -0.25f, glm::vec3(2, -4, 0));
    }
    if(currentScene == sceneList[1] || currentScene == sceneList[2] || currentScene == sceneList[3]){
        Util::DrawText(&program, fontTextureID, "Lives: " + std::to_string(lives) , 0.5f, -0.25f, glm::vec3(1, -1, 0));
    }
    if(fail){
        
        Util::DrawText(&program, fontTextureID, "GAME OVER" , 0.75f, -0.25f, glm::vec3(2.25, -4, 0));
           //DrawText(&program, fontTextureID, "YOU SCUFFED YOUR TIMBS" , 0.25f, -0.25f, glm::vec3(-4.25, 3, 0));
       }
       if(win){
           
           Util::DrawText(&program, fontTextureID, "YOU WIN" , 0.75f, -0.25f, glm::vec3(11, -4.5, 0));
          // DrawText(&program, fontTextureID, "YOU KEPT YOUR TIMBS FRESH" , 0.75f, -0.25f, glm::vec3(-3.25, 3, 0));
       }
    SDL_GL_SwapWindow(displayWindow);
}


void Shutdown() {
    Mix_FreeMusic(music);
//    Mix_FreeChunk(hit);
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    Initialize();
    
    while (gameIsRunning) {
        ProcessInput();
        Update();
        if(currentScene->state.nextScene >= 0) SwitchToScene(sceneList[currentScene->state.nextScene]);
        Render();
    }
    
    Shutdown();
    return 0;
}

