#include "Scene.h"

class Level0 : public Scene {
public:
    void Initialize() override;
    void processInput() override;
    void Update(float deltaTime) override;
    void Render(ShaderProgram *program) override;
};
