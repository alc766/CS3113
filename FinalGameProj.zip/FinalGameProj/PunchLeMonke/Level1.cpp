#include "Level1.h"

#define OBJECT_COUNT 39
//#define ENEMY_COUNT 10

//bool startGame = false;

void Level1::Initialize() {
    state.nextScene = -1;
    GLuint floorTextureID = Util::LoadTexture("concrete.png");
    Mesh *cubeMesh = new Mesh();
    cubeMesh->LoadOBJ("cube.obj", 20);
    
   // GLuint crateTextureID = Util::LoadTexture("crate1_diffuse.png");
    //Mesh *crateMesh = new Mesh();
    //crateMesh->LoadOBJ("cube.obj", 1);
    
    state.objects = new Entity[OBJECT_COUNT];
    
    state.objects[0].textureID = floorTextureID;
    state.objects[0].mesh = cubeMesh;
    state.objects[0].position = glm::vec3(0,-0.25f,0);
    state.objects[0].rotation = glm::vec3(0,0,0);
    state.objects[0].acceleration = glm::vec3(0,0,0);
    state.objects[0].scale = glm::vec3(175,0.5f,175);
    state.objects[0].entityType = FLOOR;
    
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(0, 0.75f, 0);
    state.player->acceleration = glm::vec3(0, 0, 0);
    state.player->speed = 1.0f;
    
    
//    state.objects[1].textureID = crateTextureID;
//    state.objects[1].mesh = crateMesh;
//    state.objects[1].position = glm::vec3(0,0.5,-5);
//    state.objects[1].entityType = CRATE;
//
//    state.objects[2].textureID = crateTextureID;
//    state.objects[2].mesh = crateMesh;
//    state.objects[2].position = glm::vec3(-1,0.5,-5);
//    state.objects[2].entityType = CRATE;
//
//    state.objects[3].textureID = crateTextureID;
//    state.objects[3].mesh = crateMesh;
//    state.objects[3].position = glm::vec3(0,1.5,-5);
//    state.objects[3].entityType = CRATE;
    
    //state.enemies = new Entity[ENEMY_COUNT];
    
    GLuint enemyTextureID = Util::LoadTexture("lemonke.png");
    GLuint attackerTextureID = Util::LoadTexture("evilmonke.PNG");
    for (int i = 1; i < OBJECT_COUNT-6; i++) {
        state.objects[i].billboard = true;
        state.objects[i].entityType = ENEMY;
        state.objects[i].textureID = enemyTextureID;
        state.objects[i].position = glm::vec3(rand() % 30 - 20, 0.5, rand() % 30-20);
        state.objects[i].rotation = glm::vec3(0, 0, 0);
        state.objects[i].acceleration = glm::vec3(0, 0, 0);
    }
    for(int i = OBJECT_COUNT-6; i < OBJECT_COUNT; i++){
        state.objects[i].billboard = true;
        state.objects[i].entityType = ATTACKER;
        state.objects[i].textureID = attackerTextureID;
        state.objects[i].position = glm::vec3(rand() % 40-15, 0.5, rand() % 40-15);
        state.objects[i].rotation = glm::vec3(0, 0, 0);
        state.objects[i].acceleration = glm::vec3(0, 0, 0);
    }
    
}
void Level1::processInput() {
   
        

    }

void Level1::Update(float deltaTime) {
    state.player->Update(deltaTime, state.player, state.objects, OBJECT_COUNT);
    
    for(int i = 0; i < OBJECT_COUNT; i++){
        state.objects[i].Update(deltaTime, state.player, state.objects, OBJECT_COUNT);
    }
    if(state.player->fail){
        
        state.nextScene = 3;
    }
    if(state.player->success){
           
        state.nextScene = 2;
    }
    //for(int i = 0; i < ENEMY_COUNT; i++){
     //   state.enemies[i].Update(deltaTime, state.player, state.objects, ENEMY_COUNT);
    //}
}
void Level1::Render(ShaderProgram *program){
    
   // for(int i = 0; i < OBJECT_COUNT; i++){
     //      state.objects[i].Render(program);
      // }
      // for(int i = 0; i < ENEMY_COUNT; i++){
        //      state.enemies[i].Render(program);
         // }
     //state.player->Render(program);
}
