#include "Scene.h"

class LoseScreen : public Scene {
public:
    void Initialize() override;
    void processInput() override;
    void Update(float deltaTime) override;
    void Render(ShaderProgram *program) override;
};
