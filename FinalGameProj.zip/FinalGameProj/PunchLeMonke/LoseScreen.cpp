#include "LoseScreen.h"

#define OBJECT_COUNT 1


bool restartGame2 = false;

void LoseScreen::Initialize() {
    state.nextScene = -1;
    state.objects = new Entity[OBJECT_COUNT];
        
    GLuint floorTextureID = Util::LoadTexture("concrete.png");
    Mesh *cubeMesh = new Mesh();
    cubeMesh->LoadOBJ("cube.obj", 20);
    
    state.objects[0].textureID = floorTextureID;
    state.objects[0].mesh = cubeMesh;
    state.objects[0].position = glm::vec3(0,-0.25f,0);
    state.objects[0].rotation = glm::vec3(0,0,0);
    state.objects[0].acceleration = glm::vec3(0,0,0);
    state.objects[0].scale = glm::vec3(20,0.5f,20);
    state.objects[0].entityType = FLOOR;
    
    state.player = new Entity();
    state.player->entityType = PLAYER;
    state.player->position = glm::vec3(0, 0.75f, 0);
    state.player->acceleration = glm::vec3(0, 0, 0);
    state.player->speed = 0;
    
}
void LoseScreen::processInput() {
    //SDL_Event event;
       const Uint8 *keys = SDL_GetKeyboardState(NULL);

       if (keys[SDL_SCANCODE_RETURN]) {
           //std::cout << "HERE" << std::endl;
           restartGame2 = true;

       }
}
void LoseScreen::Update(float deltaTime) {
//    void Entity::Update(float deltaTime, Entity *player, Entity *objects, int objectCount)
    state.player->Update(deltaTime, state.player, state.objects, OBJECT_COUNT);
    //for(int i = 0; i < OBJECT_COUNT; i++){
           state.objects[0].Update(deltaTime, state.player, state.objects, OBJECT_COUNT);
       //}
//    if(restartGame2){
//        //std::cout << "HERE" << std::endl;
//        restartGame2 = false;
//        state.nextScene = 1;
//
//    }
    
    
   
}
void LoseScreen::Render(ShaderProgram *program){
   // state.objects[0].Render(program);
    //state.player->Render(program);
}

