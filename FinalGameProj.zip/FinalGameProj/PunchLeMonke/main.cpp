#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1

#include <vector>
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include <iostream>
#include <SDL_mixer.h>
#include "Util.h"
#include "Entity.h"

#include "Scene.h"
#include "Level0.h"
#include "Level1.h"
#include "LoseScreen.h"
#include "WinScreen.h"

//music
//Surf Shimmy by Kevin MacLeod
//Link: https://incompetech.filmmusic.io/song/4448-surf-shimmy
//License: http://creativecommons.org/licenses/by/4.0/


using namespace std;


SDL_Window* displayWindow;
bool gameIsRunning = true;
bool attack = false;

int defeatedEnemies = 0;

bool win = false;
bool fail = false;
bool hit = false;
Scene *currentScene;
Scene *sceneList[4];
int collisionArray[32];
void SwitchToScene(Scene *scene) {
    currentScene = scene;
    currentScene->Initialize();
}

int lifeCount = 3;
ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

GLuint heartTextureID;
glm::mat4 uiViewMatrix, uiProjectionMatrix;
GLuint fontTextureID;

Mix_Music *music;
Mix_Chunk *death;
Mix_Chunk *enemyDeath;
Mix_Chunk *punch;

//GameState state;

void Initialize() {
    SDL_Init(SDL_INIT_VIDEO);
    displayWindow = SDL_CreateWindow("PUNCH LE MONKE", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 720, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
    
#ifdef _WINDOWS
    glewInit();
#endif
    
    glViewport(0, 0, 1280, 720);
    
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    music = Mix_LoadMUS("surf-shimmy.mp3");
    Mix_PlayMusic(music, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
    death = Mix_LoadWAV("death.wav");
    punch = Mix_LoadWAV("oof3.wav");
    enemyDeath = Mix_LoadWAV("enemyDeath.wav");
    uiViewMatrix = glm::mat4(1.0);
    uiProjectionMatrix = glm::ortho(-6.4f, 6.4f, -3.6f, 3.6f, -1.0f, 1.0f);
    fontTextureID = Util::LoadTexture("font1.png");
    
    viewMatrix = glm::mat4(1.0f);
    modelMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::perspective(glm::radians(45.0f), 1.777f, 0.1f, 100.0f);
    
    
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);
    
    glUseProgram(program.programID);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_DEPTH_TEST);
    glDepthMask(GL_TRUE);
    glDepthFunc(GL_LEQUAL);
    

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    
    sceneList[0] = new Level0();
    sceneList[1] = new Level1();
    sceneList[2] = new WinScreen();
    sceneList[3] = new LoseScreen();
    SwitchToScene(sceneList[0]);
      
    
    
    
}

void ProcessInput() {
    
    //currentScene->state.player->movement = glm::vec3(0);
    
    if(currentScene == sceneList[0]){
        currentScene->processInput();
    }
    if(currentScene == sceneList[2]){
        currentScene->processInput();
    }
    if(currentScene == sceneList[3]){
        currentScene->processInput();
    }
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        
        switch (event.type) {
            case SDL_QUIT:
            case SDL_WINDOWEVENT_CLOSE:
                gameIsRunning = false;
                break;
                
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_SPACE:
                        Mix_PlayChannel(-1, punch, 0);
                        Mix_VolumeChunk(punch, MIX_MAX_VOLUME/2);
                        if(currentScene->state.player->collide){
                            attack = true;
                        }
                       
                        // Some sort of action
                        break;
                        
                }
                //attack = false;
                break;
        }
    }
    
    const Uint8 *keys = SDL_GetKeyboardState(NULL);
    
    if (keys[SDL_SCANCODE_A] && currentScene != sceneList[0]) {
        currentScene->state.player->rotation.y += 3.35f;
    } else if (keys[SDL_SCANCODE_D]&& currentScene != sceneList[0]) {
        currentScene->state.player->rotation.y -= 3.35f;
    }
    
    currentScene->state.player->velocity.x = 0;
    currentScene->state.player->velocity.z = 0;
    
    if (keys[SDL_SCANCODE_W]&& currentScene != sceneList[0]) {
        currentScene->state.player->velocity.z = cos(glm::radians(currentScene->state.player->rotation.y)) * -3.75f;
        currentScene->state.player->velocity.x = sin(glm::radians(currentScene->state.player->rotation.y)) * -3.75f;
    } else if (keys[SDL_SCANCODE_S]&& currentScene != sceneList[0]) {
        currentScene->state.player->velocity.z = cos(glm::radians(currentScene->state.player->rotation.y)) * 3.75f;
        currentScene->state.player->velocity.x = sin(glm::radians(currentScene->state.player->rotation.y)) * 3.75f;
    }
    
}

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update() {
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP) {
        accumulator = deltaTime;
        return;
    }
    
    while (deltaTime >= FIXED_TIMESTEP) {
        
        currentScene->Update(FIXED_TIMESTEP);
        
        if(currentScene->state.player->collide == true && attack == true){
            //if(collisionArray[currentScene->state.player->indexOfEnemy] == false){
                defeatedEnemies += 1;
                Mix_PlayChannel(-1, enemyDeath, 0);
                Mix_VolumeChunk(enemyDeath, MIX_MAX_VOLUME);
                currentScene->state.objects[currentScene->state.player->indexOfEnemy].isActive = false;
                attack = false;
            //}
            
            
        }
        
        if(currentScene->state.player->collideAttacker == true){
            Mix_PlayChannel(-1, death, 0);
            Mix_VolumeChunk(death, MIX_MAX_VOLUME/3);
            lifeCount -= 3;
            
        }
        
        
       
        deltaTime -= FIXED_TIMESTEP;
    }
    
    accumulator = deltaTime;
    viewMatrix = glm::mat4(1.0f);
    viewMatrix = glm::rotate(viewMatrix, glm::radians(currentScene->state.player->rotation.y), glm::vec3(0, -1.0f, 0));
    viewMatrix = glm::translate(viewMatrix, -currentScene->state.player->position);
}
void sleep(int milliseconds)
{
    clock_t time_end = time_end = clock() + milliseconds * CLOCKS_PER_SEC/1000;
    while (clock() < time_end) {}
}
int timeInMenu;
void Render() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
   
   program.SetProjectionMatrix(projectionMatrix);
   program.SetViewMatrix(viewMatrix);
    
    //state.player->Render(&program);
    
    if(currentScene == sceneList[0]){
        currentScene->state.objects[0].Render(&program);
        //currentScene->state.player->Render(&program);
    }
    if(currentScene == sceneList[1]){
        
        for(int i = 0; i < 39; i++){
              currentScene->state.objects[i].Render(&program);
          }
          
        if(((130+timeInMenu) - (SDL_GetTicks()/1000)) <= 0 || lifeCount == 0){
            currentScene->state.player->fail = true;
        }
        if(defeatedEnemies == 32){
            currentScene->state.player->success = true;
        }
//        for(int i = 33; i < 39; i++){
//            if(currentScene->state.enemies[i].entityType == ATTACKER){
//                if(currentScene->state.enemies[i].position >= currentScene->state.player->position + glm::vec3(1.0f,1.0f,1.0f)){
//
//                }
//            }
//        }
       
        //currentScene->state.player->Render(&program);
    }
    //currentScene->Render(&program);
   
    program.SetProjectionMatrix(uiProjectionMatrix);
    program.SetViewMatrix(uiViewMatrix);
    //(glm::vec3(left/right,up/down,___)
    if(currentScene == sceneList[0]){
        Util::DrawText(&program, fontTextureID, "PRESS ENTER TO START", 0.75, -0.3f, glm::vec3(-4, 0, 0));
        Util::DrawText(&program, fontTextureID, "PUNCH LE MONKE", 0.75, -0.3f, glm::vec3(-2.5, 2, 0));
        timeInMenu = (SDL_GetTicks()/1000);
        
    }
    
    if(currentScene == sceneList[1]){
        
       
        Util::DrawText(&program, fontTextureID, "TIME: " + std::to_string((130+timeInMenu) - (SDL_GetTicks()/1000)), 0.5, -0.3f, glm::vec3(-6, 3.2, 0));
        
    }
    
    if(currentScene == sceneList[2]){
        Util::DrawText(&program, fontTextureID, "YOU WIN", 0.75, -0.3f, glm::vec3(-2, 0, 0));
    }
    if(currentScene == sceneList[3]){
        Util::DrawText(&program, fontTextureID, "YOU LOSE", 0.75, -0.3f, glm::vec3(-2, 0, 0));
    }
    
    //for(int i = 0; i < lifeCount; i++){
     //   Util::DrawIcon(&program, heartTextureID, glm::vec3(5 + (i * 0.5f), 3.2, 0));
    //}
    SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    
    Initialize();
    
    while (gameIsRunning) {
        ProcessInput();
        Update();
        if(currentScene->state.nextScene >= 0) SwitchToScene(sceneList[currentScene->state.nextScene]);
        Render();
    }
    
    Shutdown();
    return 0;
}
